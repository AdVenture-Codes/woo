<?php

// Don't redefine the functions if included multiple times.
if (!\function_exists('Automattic\WooCommerce\Bookings\Vendor\GuzzleHttp\describe_type')) {
    require __DIR__ . '/functions.php';
}

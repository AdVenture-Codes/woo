<?php
abstract class WC_Bookings_Data extends WC_Data {}
